package com.retouno.unoweb;

import com.retouno.unoweb.crud.OrdenesCrud;
import com.retouno.unoweb.crud.ProductoCrud;
import com.retouno.unoweb.crud.UserCrud;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

@Component
@SpringBootApplication
public class UnowebApplication implements CommandLineRunner{

	@Autowired
	private ProductoCrud productoCrud;
	@Autowired 
	private UserCrud userCrud;
	@Autowired
	private OrdenesCrud ordenesCrud;

	public static void main(String[] args) {
		SpringApplication.run(UnowebApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception{
		productoCrud.deleteAll();
		userCrud.deleteAll();
		ordenesCrud.deleteAll();


	}

}
