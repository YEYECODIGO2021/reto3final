package com.retouno.unoweb.repository;

import java.util.List;
import java.util.Optional;

import com.retouno.unoweb.crud.OrdenesCrud;
import com.retouno.unoweb.model.Ordenes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RepositoryOrdenes {

    @Autowired
    private OrdenesCrud ordenesCrud;

    public Ordenes guardarOrden(Ordenes orden){
        return ordenesCrud.save(orden);
    }

    public Optional<Ordenes> OrdenXid(int id){
        return ordenesCrud.findById(id);
    }

    public Optional<Ordenes> ultimaOrden(){
        return ordenesCrud.findTopByOrderByIdDesc();    
    }

    public List<Ordenes> getFullOrdenes(){
        return ordenesCrud.findAll();
}

public void updateOrden(Ordenes orden){
    ordenesCrud.save(orden);
}

public void deleteOrden(int id){
    ordenesCrud.deleteById(id);
}

public List<Ordenes>ordenesXZona(String country){
    return ordenesCrud.findByZone(country);
}



}
