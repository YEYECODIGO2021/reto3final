package com.retouno.unoweb.repository;

import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.crud.ProductoCrud;
import com.retouno.unoweb.model.Cosmeticos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RepositoryProduct {

    @Autowired
    private ProductoCrud productoCrud;

    public Cosmeticos saveProduct(Cosmeticos product){
        return productoCrud.save(product);
    }

    public List<Cosmeticos> listarCosmeticos(){
        return (List<Cosmeticos>)productoCrud.findAll();
        
    }
    
    public Optional<Cosmeticos> productxId(String id){
        return productoCrud.findById(id);
    }

    public void actualizarProduct(Cosmeticos Nproducto){
        productoCrud.save(Nproducto);
    }

    public void eliminar(Cosmeticos productDel){
        productoCrud.delete(productDel);
    }
    

}
