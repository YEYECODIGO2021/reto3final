package com.retouno.unoweb.controller;

import java.util.List;
import java.util.Optional;

import com.retouno.unoweb.model.Ordenes;
import com.retouno.unoweb.service.OrdenServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("api/order")
@CrossOrigin("*")
public class OrdenContro {

    @Autowired
    private OrdenServicio ordenServicio;

@PostMapping("/new")
@ResponseStatus(HttpStatus.CREATED)
public Ordenes guardarOrden(@RequestBody Ordenes orden) {
    return ordenServicio.guardarOrden(orden);
}

@GetMapping("/all")
public List<Ordenes>obtenerOrdenes(){
    return ordenServicio.getOrdenes();
}

@GetMapping("/zona/{zona}")
public List<Ordenes> listaOrdenesZona(@PathVariable("zona")String country){
    return ordenServicio.ordenesZona(country);
}

@GetMapping("/{id}")
public Optional<Ordenes> getOrdenId(@PathVariable("id") Integer id){
    return ordenServicio.getOrden(id);
}
@DeleteMapping("/{id}")
@ResponseStatus(HttpStatus.NO_CONTENT)
public boolean eliminar(@PathVariable("id") Integer id ){
    return ordenServicio.eliminarOrden(id);
}

@PutMapping("/update")
@ResponseStatus(HttpStatus.CREATED)
public Ordenes actualizarOrden(@RequestBody Ordenes orden){
    return ordenServicio.actulizarOrden(orden);

}
           
}
