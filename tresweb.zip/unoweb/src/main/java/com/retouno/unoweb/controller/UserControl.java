package com.retouno.unoweb.controller;

import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.model.Usuario;
import com.retouno.unoweb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author yeison
 */
@RestController
@RequestMapping("api/user")
@CrossOrigin("*")
public class UserControl {
/**
 * instancia user servicio
 */
    @Autowired
    private UserService userService;

    /**
     * Guardar nuevo usuario
     * @param usuario
     * @return
     */
    @PostMapping("/new")
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario guardarNuevo(@RequestBody Usuario usuario){
        return userService.guardarUser(usuario);    
    }

    /**
     * obtener todos los usuarios
     * @return
     */
    @GetMapping("/all")
    public List<Usuario> listaUsers(){
        return userService.getListUsers();
    }
/**
 * Obtener un usuario
 * @param id
 * @return
 */
    @GetMapping("/{id}")
    public Optional<Usuario> getUsuariosxID(@PathVariable("id") Integer id){
        return userService.getUsuario(id);
    }
/**
 * validar por email y password
 * @param email
 * @param password
 * @return
 */
    @GetMapping("/{email}/{password}")
    public Usuario validarInicio(@PathVariable("email") String email, @PathVariable("password") String password){
        return userService.validarLoggin(email, password);
    }
/**
 * validar usuario si existe
 * @param email
 * @return
 */
    @GetMapping("/emailexist/{email}")
    public boolean existenciaEmail(@PathVariable("email") String email){
        return userService.existeCorreo(email);
    }
/**
 * eliminar usuario por id
 * @param usuarioId
 * @return
 */
    @DeleteMapping("/{Id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public boolean eliminar(@PathVariable("Id") Integer usuarioId){
        return userService.deleteUser(usuarioId);
    }
    
    /**
     * actualizar un usuario existente
     * @param usuario
     * @return
     */
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario actualizarUsuario(@RequestBody Usuario usuario){
        return userService.actualizarUser(usuario);
    }

    
}
