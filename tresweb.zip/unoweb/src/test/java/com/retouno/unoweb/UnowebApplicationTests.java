package com.retouno.unoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
