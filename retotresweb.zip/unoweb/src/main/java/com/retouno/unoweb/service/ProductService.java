package com.retouno.unoweb.service;

import java.util.List;
import java.util.Optional;

import com.retouno.unoweb.model.Cosmeticos;
import com.retouno.unoweb.repository.RepositoryProduct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired
    private RepositoryProduct repositoryProduct;

    public Cosmeticos guadarNew(Cosmeticos productNew){
    if(productNew.getReference()==null){
        return productNew;
    }else{
        Optional<Cosmeticos> producto = repositoryProduct.productxId(productNew.getReference());
        if(producto.isEmpty()){
            return repositoryProduct.saveProduct(productNew);
        }else{
            return productNew;
        }
    }
    }

public List<Cosmeticos>getProductos(){
    return repositoryProduct.listarCosmeticos();
}

public Optional<Cosmeticos> getUnProducto(String id){
    return repositoryProduct.productxId(id);
}

public boolean deleteProduct(String id){
    Boolean aBoolean = getUnProducto(id).map(user->{
        repositoryProduct.eliminar(user);
        return true;
    }).orElse(false);
    return aBoolean;
}
public Cosmeticos actualizarProd(Cosmeticos productoPut){
    if(productoPut.getReference()!=null){
        Optional<Cosmeticos> consultar = getUnProducto(productoPut.getReference());
        if(!consultar.isEmpty()){
            if(productoPut.getBrand()!=null){consultar.get().setBrand(productoPut.getBrand());}
            if(productoPut.getCategory()!=null){consultar.get().setCategory(productoPut.getCategory());}
            if(productoPut.getDescription()!=null){consultar.get().setDescription(productoPut.getDescription());}
            if(productoPut.getName()!=null){consultar.get().setName(productoPut.getName());}
            if(productoPut.getPhotography()!=null){consultar.get().setPhotography(productoPut.getPhotography());}
            if(productoPut.getPrice()!=0.0){consultar.get().setPrice(productoPut.getPrice());}
            if(productoPut.getQuantity()!=0){consultar.get().setQuantity(productoPut.getQuantity());}
            consultar.get().setAvailability(productoPut.isAvailability());
            repositoryProduct.actualizarProduct(consultar.get());
            return consultar.get();
        }else{
            return productoPut;
        }
    }else {
        return productoPut;
    }
}

    
}
