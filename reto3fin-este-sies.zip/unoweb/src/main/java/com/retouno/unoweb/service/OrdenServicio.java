package com.retouno.unoweb.service;

import java.util.List;
import java.util.Optional;

import com.retouno.unoweb.model.Ordenes;
import com.retouno.unoweb.repository.RepositoryOrdenes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrdenServicio {

    @Autowired
    private RepositoryOrdenes repositoryOrdenes;

    public Ordenes guardarOrden(Ordenes orden){
        Optional<Ordenes> ultimaOrden = repositoryOrdenes.ultimaOrden();
    if(orden.getId()==null){
        if(ultimaOrden.isEmpty()){
            orden.setId(1);
        }else{
            orden.setId(ultimaOrden.get().getId()+1);
        }
    }
    Optional<Ordenes> newOrden = repositoryOrdenes.OrdenXid(orden.getId());
    if(newOrden.isEmpty()){
        return repositoryOrdenes.guardarOrden(orden);
    }else{
        return orden;

    }
    
}
public List<Ordenes> getOrdenes(){
    return repositoryOrdenes.getFullOrdenes();
}

public Optional<Ordenes> getOrden(int id){
    return repositoryOrdenes.OrdenXid(id);
}

public Ordenes actulizarOrden(Ordenes orden){
    if(orden.getId()!=null){
        Optional<Ordenes> existOrden = repositoryOrdenes.OrdenXid(orden.getId());
        if(!existOrden.isEmpty()){
            if(orden.getStatus()!=null){existOrden.get().setStatus(orden.getStatus());}
            repositoryOrdenes.updateOrden(existOrden.get());
            return existOrden.get();
        }else{
            return orden;
        }
    }else{
        return orden;
    }}

public boolean eliminarOrden(int id){
    Boolean aBoolean = getOrden(id).map(orden->{
        repositoryOrdenes.deleteOrden(id);
        return true;
    }).orElse(false);
    return aBoolean;
}

public List<Ordenes> ordenesZona(String country){
    return repositoryOrdenes.ordenesXZona(country);
}

}  